<?php
include 'datos.php';

echo $videoclub;
?>

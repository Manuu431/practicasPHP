<?php
echo "<a href='aplicacion.php'>Entrar a la aplicación</a>";
?>
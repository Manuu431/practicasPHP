<?php 
include "funciones.php";
// include "funciones.php";

function validar(){
    if ($_POST['dni'] == null || $_POST['nombre'] == null || $_POST['direccion'] == null
    || $_POST['localidad'] == null || $_POST['provincia'] == null || $_POST['telefono'] == null || $_POST['email'] == null ){
        return false;
    }
    return true;
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Modificar cliente</title>
</head>
<body>
    <?php
    $dni = $_REQUEST['dni'];
    $cliente = encontrarCliente($dni);
    ?>
    <h3>Modificar cliente</h3>
    <form method="POST" action="clientenuevo.php">
        <label for="dni">DNI:</label>
        <input disabled='true' value='<?php echo $cliente['dni']?>' type="text" id="dni" name="dni"><br>
        <label for="nombre">Nombre:</label>
        <input value='<?php echo $cliente['nombre']?>' type="text" id="nombre" name="nombre"><br>
        <label for="direccion">Direccion:</label>
        <input value='<?php echo $cliente['direccion']?>' type="text" id="direccion" name="direccion"><br>
        <label for="localidad">Localidad:</label>
        <input value='<?php echo $cliente['localidad']?>' type="text" id="localidad" name="localidad"><br>
        <label for="provincia">Provincia:</label>
        <input value='<?php echo $cliente['provincia']?>' type="text" id="provincia" name="provincia"><br>
        <label for="telefono">Telefono:</label>
        <input value='<?php echo $cliente['telefono']?>' type="text" id="telefono" name="telefono"><br>
        <label for="email">Email:</label>
        <input value='<?php echo $cliente['email']?>' type="text" id="email" name="email"><br>

        <?php
        echo "<button type='submit'>Guardar cliente</button><br>";
        echo "<a href='index.php'>Volver</a><br>";

        if ($_SERVER['REQUEST_METHOD'] == 'POST') {
            if (isset($_POST['dni']) && isset($_POST['nombre']) && isset($_POST['direccion']) 
            && isset($_POST['localidad']) && isset($_POST['provincia']) && isset($_POST['telefono']) && isset($_POST['email'])){
                if(!validar()){
                    echo "Todos los campos deben estar llenos";
                }
                else{
                    if(insertarDatos($_POST['dni'], $_POST['nombre'], $_POST['direccion'], $_POST['localidad'], $_POST['provincia'], $_POST['telefono'], $_POST['email'])                    ){
                        header("Location:index.php?mensaje=insertok&&nombre={$_POST['nombre']}");
                    }
                    else{
                        echo "No se ha podido conectar con la base de datos, inténtelo más tarde";
                    }
                }
            }
        }
        ?>
    </form>
</body>
</html>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Index</title>
</head>
<style>
    table, th, tr, td{
        border: 1px solid black;
        border-collapse: collapse;
    }
    th{
        background-color: orange;
    }
    button{

    }
</style>
<body>
<?php
include "funciones.php";

conexionDB();

// insertarDatos("23232324F", "Pablo", "C/ Ejemplo", "Pego", "Alicante", "654654654", "pablo@gmail.com");
// insertarDatos("23232325F", "Pablo", "C/ Ejemplo", "Pego", "Alicante", "654654654", "pablo@gmail.com");
?>
<table>
    <tr>
        <th>DNI</th>
        <th>Nombre</th>
        <th>Dirección</th>
        <th>Localidad</th>
        <th>Provincia</th>
        <th>Teléfono</th>
        <th>Email</th>
        <th style='background-color:green'>Editar</th>
        <th style='background-color:red'>Borrar</th>
    </tr>
<?php crearTabla();?>
</table>

<?php
if(isset($_REQUEST["mensaje"]) && $_REQUEST["mensaje"] == "insertok"){
    echo "El cliente llamado {$_REQUEST['nombre']} ha sido insertado correctamente.<br>";
}
echo "<a href='clientenuevo.php'><button>Nuevo cliente</button></a>"
?>
</body>
</html>
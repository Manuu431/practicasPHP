<?php
include "insert.php";
function conexionDB() {
    try{
        $con = new PDO('mysql:host=localhost;dbname=clientesDB', 'manu', 'manu');
        // $con = new PDO('mysql:host=192.168.122.1;dbname=clientes_db', 'jefe', 'jefe');
        $con->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        // echo "La conexión ha sido un éxito.<br>";
    }
    catch(PDOException $e) {
        echo 'Error: '. $e->getMessage();
    }
}

function cerrarConexionDB($con) {
    // Cerrar la conexión explícitamente asignando el objeto PDO a null
    $con = null;
    echo "Conexión cerrada.<br>";
}

function crearTabla(){
    try{
        $pdo = new PDO('mysql:host=localhost;dbname=clientesDB', 'manu', 'manu');
        $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    
        $stmt = $pdo->prepare('SELECT * FROM clientes');
        $stmt->execute();
    
        while ($fila = $stmt->fetch(PDO::FETCH_ASSOC)) {
            echo "<tr>";
            echo "<td>" . htmlspecialchars($fila['dni']) . "</td>";
            echo "<td>" . htmlspecialchars($fila['nombre']) . "</td>";
            echo "<td>" . htmlspecialchars($fila['direccion']) . "</td>";
            echo "<td>" . htmlspecialchars($fila['localidad']) . "</td>";
            echo "<td>" . htmlspecialchars($fila['provincia']) . "</td>";
            echo "<td>" . htmlspecialchars($fila['telefono']) . "</td>";
            echo "<td>" . htmlspecialchars($fila['email']) . "</td>";
            echo "<td><a href='editarCliente.php?dni=" . $fila['dni'] . "'><button>Editar</button></a></td>";
            echo "<td><a href='borrarCliente.php?dni=" . $fila['dni'] . "'><button>Eliminar</button></a></td>";   
            echo "</tr>";
        }
    }
    catch (PDOException $e) {
        echo 'Error: ' . $e->getMessage();
    }
    finally{
        // Cerrar la conexión
        $pdo = null; // Esto cierra explícitamente la conexión
    }
}

function encontrarCliente($dni){
    try {
        // Conectar a la base de datos
        $pdo = new PDO('mysql:host=localhost;dbname=clientesDB', 'manu', 'manu');
        $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

        // Preparar la consulta para obtener los datos del cliente por su dni
        $stmt = $pdo->prepare('SELECT * FROM clientes WHERE dni = :dni');
        $stmt->bindParam(':dni', $dni, PDO::PARAM_STR);
        $stmt->execute();

        // Obtener los datos del cliente
        $cliente = $stmt->fetch(PDO::FETCH_ASSOC);

        if ($cliente) {
            // echo $cliente['dni'];
            // echo $cliente['nombre'];
            return $cliente;
            // Mostrar el formulario con los datos del cliente
        } else {
            echo "Cliente no encontrado.";
        }
    } catch (PDOException $e) {
        echo 'Error: ' . $e->getMessage();
    } finally {
        // Cerrar la conexión
        $pdo = null;
    }
}
?>